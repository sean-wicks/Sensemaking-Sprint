# Untitled Problem Situation

(no problem situation mapped yet)

---

## What comes next
This situation is mapped but not solved — and solving it is not the next step. The next steps in Frame Creation are:

1. **Map the field** — identify every player connected to this situation or a future resolution. Define each by their practices and currency, not their title. Look especially for players who share the values your themes surfaced — even in distant, unexpected domains.
2. **Identify a client** — from the potential problem owners, who could own this situation or adopt a resolution? What would they need to see?
3. **Choose a delivery context** — through what kind of vehicle does a resolution reach the field? (An internal team, a government program, an open-source project, a startup, a nonprofit, a civic institution, a co-op — there is no right answer, only trade-offs.)
4. **Deepen the archaeology** — the gaps above name what's still thin. Go find it: interview people, run deep-research sweeps, pull secondary sources.
5. **Create frames** — only after the field is mapped and the archaeology is deep. "If this situation is approached as if it is ___, then ___."
