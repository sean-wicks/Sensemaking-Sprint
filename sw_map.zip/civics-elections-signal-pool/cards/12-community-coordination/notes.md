# Community Coordination

*Evidence · Evidence*

Communities don't have an easy way to make needs known and recruit volunteers.

## Built from

  - Signal "Campus–Neighborhood Disconnection": There is no single, easy channel for a university community and its neighbors to trade information and opportunities — student jobs, local events, programs, and campus resources live in scattered slices.
  - Signal "Volunteer Burnout & Knowledge Transfer": Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
  - Signal "Complacency & Candidate Deterrence": The average citizen doesn't feel they can make a difference, and good people stay away from political office because media can form any narrative it wants about them.
  - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
  - Signal "Cross-Agency Coordination Failure": Constituent problems take years to solve because coordinating local, federal, and neighboring-state agencies, private entities, and residents is nearly impossible — stakeholders claim jurisdiction for credit and duck it for problem-solving, at great cost to unpaid commissioners.
