# Deliberate Obfuscation

*Evidence · Evidence*

It may be an advantage to confuse people.

## Built from

  - Signal "Uncontested Local Candidate Transparency": It is incredibly difficult to research the records of local election candidates, especially those running uncontested or without a communications budget, leaving voters feeling uninformed.
  - Signal "Representatives Without Accountability": Representatives don't seem to answer to the people, and replacing them changes little — new reps inherit the same voting patterns, with the two-party system and polarization at the crux.
  - Signal "AI Bot Interference in Constituent Engagement": Artificial intelligence is being used to flood communication channels, rendering actual, organic constituent engagement ineffective.
  - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
  - Signal "Accountability for Public Lies": Telling the truth — and holding liars accountable and responsible — is named as the missing piece of civic life.
  - Signal "False Transparency in Government": Government agencies and schools exhibit a disconnect with their constituencies, presenting a 'false flag' of transparency that leaves communities feeling ignored without understanding how aggregate sentiment is utilized.
  - Signal "Performative Bipartisanship": Statements, town halls, and pledges perform collaboration without doing it; missing is a structured, sprint-like way for people who are supposed to disagree to define a shared problem and build something together.
