# Vote Enhancement

*Evidence · Evidence*

Rules are changed to benefit voters.

## Built from

  - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.
  - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
  - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.
