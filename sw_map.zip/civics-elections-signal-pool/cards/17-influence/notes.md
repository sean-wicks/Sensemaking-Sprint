# Influence

*Evidence · Evidence*

Some communities have an outsized effect on representation.

## Built from

  - Signal "Campaign Finance": Reform efforts consistently hit roadblocks like the Citizens United decision.
  - Signal "Targeting Legislative Influence": It is currently too labor-intensive and expensive to identify the most effective individuals or groups to lobby specific legislators on specific issues at the right time.
  - Signal "Campaign Finance & District Competitiveness": Observations that financial influence and gerrymandering have reduced the competitiveness of congressional districts.
