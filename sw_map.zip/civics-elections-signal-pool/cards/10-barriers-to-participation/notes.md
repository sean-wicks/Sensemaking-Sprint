# Barriers to Participation

*Evidence · Evidence*

There are hurdles that stop people from voting.

## Built from

  - Signal "Last-Mile Resource Disconnect": Programs, grants, and services exist on paper, but communities often don't know about them or can't navigate them — the gap is grassroots outreach, trusted local partners, and hands-on navigation support, not new programs.
  - Signal "Logistical & Educational Barriers to Voting": Voting is burdened by physical hurdles (childcare, time off work) and a lack of plain-language education on how local elections directly impact citizens' daily lives.
