# Forming Expectations

*Evidence · Evidence*

People have the wrong idea about how long things will take, which leads to them becoming disenfranchised.

## Built from

  - Signal "Volunteer Burnout & Knowledge Transfer": Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
  - Signal "Misunderstood Pace of Government": Constituents misjudge who holds which powers and how fast government was designed to move, so legitimate slowness reads as failure — and stretched congressional staff can't give every issue the weight visitors expect.
  - Signal "Hopelessness & Lack of Election Information": Voters feel hopeless and lack basic awareness of when local elections occur, relying on passive information like mailers or word of mouth.
  - Signal "Constituent Mail Black Hole": Letters and emails to representatives feel like talking into a void — heartfelt messages come back as generic, strategist-polished boilerplate.
