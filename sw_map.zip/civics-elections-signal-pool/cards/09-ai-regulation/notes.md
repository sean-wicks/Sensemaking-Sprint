# AI Regulation

*Evidence · Evidence*

Political parties are using AI as a tool, and are not incentivized to regulate it.

## Built from

  - Signal "AI Bot Interference in Constituent Engagement": Artificial intelligence is being used to flood communication channels, rendering actual, organic constituent engagement ineffective.
  - Signal "Public Engagement on Government AI": Citizens lack the tools and platforms to provide feedback on or inform how government agencies and companies deploy artificial intelligence in their communities.
