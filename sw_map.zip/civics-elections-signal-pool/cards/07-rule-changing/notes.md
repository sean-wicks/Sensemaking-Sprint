# Rule Changing

*Pattern*

The rules of the game are constantly changing.

## Built from

  • Evidence: Influence — Some communities have an outsized effect on representation.                                                                                                                                                                                                          
    - Signal "Campaign Finance": Reform efforts consistently hit roadblocks like the Citizens United decision.
    - Signal "Targeting Legislative Influence": It is currently too labor-intensive and expensive to identify the most effective individuals or groups to lobby specific legislators on specific issues at the right time.
    - Signal "Campaign Finance & District Competitiveness": Observations that financial influence and gerrymandering have reduced the competitiveness of congressional districts.
  • Evidence: Vote Dilution — Rules are changed to benefit political entities by stopping people voting and diluting the effectiveness of their votes.
    - Signal "Structural Election Imbalances": The current electoral system features gerrymandering, dominant two-party privileges, and districts so large that politicians effectively choose their voters.
    - Signal "Mid-Decade Redistricting Shifts": California, Missouri, North Carolina, and Texas will use different congressional maps in 2026 than in 2024 due to voluntary mid-decade redistricting — unusual, and worth watching for how it shifts competitive-district counts.
    - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.
  • Evidence: Vote Enhancement — Rules are changed to benefit voters.
    - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.
    - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
    - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.
