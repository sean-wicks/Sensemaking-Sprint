# People have difficulty supporting their communities, at all levels of government.

> A problem situation mapped using Kees Dorst's Frame Creation method.
> Built from 19 cards covering 33 signals across the evidence ladder.
> Exported 2026-07-25T20:22:50.350Z.

## The situation
Every community's specific problems will be different. Different communities have differently sized voices at the national scale, and employ different strategies to support themselves.

People need a place to talk to people who are not like themselves.

### Why this is open, not bounded
Variability in community resources.

### Evidence trail
• Evidence: Forming Expectations — People have the wrong idea about how long things will take, which leads to them becoming disenfranchised.                                                                                                                                                                                                                                                             
  - Signal "Volunteer Burnout & Knowledge Transfer": Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
  - Signal "Misunderstood Pace of Government": Constituents misjudge who holds which powers and how fast government was designed to move, so legitimate slowness reads as failure — and stretched congressional staff can't give every issue the weight visitors expect.
  - Signal "Hopelessness & Lack of Election Information": Voters feel hopeless and lack basic awareness of when local elections occur, relying on passive information like mailers or word of mouth.
  - Signal "Constituent Mail Black Hole": Letters and emails to representatives feel like talking into a void — heartfelt messages come back as generic, strategist-polished boilerplate.
• Evidence: AI Regulation — Political parties are using AI as a tool, and are not incentivized to regulate it.
  - Signal "AI Bot Interference in Constituent Engagement": Artificial intelligence is being used to flood communication channels, rendering actual, organic constituent engagement ineffective.
  - Signal "Public Engagement on Government AI": Citizens lack the tools and platforms to provide feedback on or inform how government agencies and companies deploy artificial intelligence in their communities.
• Super-theme: Limited Agency — Some voters and communities are less able to represent their needs on a national scale.
  • Theme: Specific Needs aren't Met — Communities aren't able to communicate where they need help or where help is needed.

Even if they could, people don't know how to help.

Therefore, the community's needs aren't met.
    • Pattern: Lack of Specific Education — Communities don't have an easy way to educate people regarding their specific                                                                                                                                                                                                                                                                        needs.                                                                                                                                       
      • Evidence: Community Coordination — Communities don't have an easy way to make needs known and recruit volunteers.
        - Signal "Campus–Neighborhood Disconnection": There is no single, easy channel for a university community and its neighbors to trade information and opportunities — student jobs, local events, programs, and campus resources live in scattered slices.
        - Signal "Volunteer Burnout & Knowledge Transfer": Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
        - Signal "Complacency & Candidate Deterrence": The average citizen doesn't feel they can make a difference, and good people stay away from political office because media can form any narrative it wants about them.
        - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
        - Signal "Cross-Agency Coordination Failure": Constituent problems take years to solve because coordinating local, federal, and neighboring-state agencies, private entities, and residents is nearly impossible — stakeholders claim jurisdiction for credit and duck it for problem-solving, at great cost to unpaid commissioners.
      • Evidence: Education — People don't know how things work or how to change them.         
        - Signal "Broad Civic Disengagement": Many people are not engaged in local or national politics, don't know who the candidates are or what they stand for, and don't vote — despite candidate forums and get-out-the-vote efforts.
        - Signal "Misunderstood Pace of Government": Constituents misjudge who holds which powers and how fast government was designed to move, so legitimate slowness reads as failure — and stretched congressional staff can't give every issue the weight visitors expect.
        - Signal "Local Candidate Information Gaps": Voters lack easily accessible, actionable information about local county-level candidates, often relying heavily on name recognition from campaign signs.
        - Signal "Uncontested Local Candidate Transparency": It is incredibly difficult to research the records of local election candidates, especially those running uncontested or without a communications budget, leaving voters feeling uninformed.
        - Signal "Logistical & Educational Barriers to Voting": Voting is burdened by physical hurdles (childcare, time off work) and a lack of plain-language education on how local elections directly impact citizens' daily lives.
        - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.
        - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
        - Signal "Last-Mile Resource Disconnect": Programs, grants, and services exist on paper, but communities often don't know about them or can't navigate them — the gap is grassroots outreach, trusted local partners, and hands-on navigation support, not new programs.
        - Signal "Hopelessness & Lack of Election Information": Voters feel hopeless and lack basic awareness of when local elections occur, relying on passive information like mailers or word of mouth.
        - Signal "No Playbook for Good Citizenship": There is no clear guide to the daily, weekly, and monthly steps of being an informed, participating citizen — the information is scattered everywhere, and the whole project feels overwhelming.
        - Signal "Unexplained Ballot Roles": Even where ranked-choice mechanics were well taught, voters lack a plain-language breakdown of what each office on the ballot actually does, leaving first-time voters guessing at the roles they're electing.
    • Pattern: Lack of Communication — People aren't talking to each other.                                                                                                                                             
      • Evidence: Community Coordination — Communities don't have an easy way to make needs known and recruit volunteers.
        - Signal "Campus–Neighborhood Disconnection": There is no single, easy channel for a university community and its neighbors to trade information and opportunities — student jobs, local events, programs, and campus resources live in scattered slices.
        - Signal "Volunteer Burnout & Knowledge Transfer": Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
        - Signal "Complacency & Candidate Deterrence": The average citizen doesn't feel they can make a difference, and good people stay away from political office because media can form any narrative it wants about them.
        - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
        - Signal "Cross-Agency Coordination Failure": Constituent problems take years to solve because coordinating local, federal, and neighboring-state agencies, private entities, and residents is nearly impossible — stakeholders claim jurisdiction for credit and duck it for problem-solving, at great cost to unpaid commissioners.
      • Evidence: Cloistering — People inside communities don't talk to people outside their communities.
        - Signal "Loneliness as a Civic Problem": The social scaffolding that once created accountability in how people form relationships has dissolved with nothing replacing it — an isolation epidemic treated as a private matter rather than missing civic infrastructure.
        - Signal "Volunteer Burnout & Knowledge Transfer": Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
        - Signal "Anemic, Uneven Participation": Civic participation is thin, and only some voices get heard and lifted.
        - Signal "Campus–Neighborhood Disconnection": There is no single, easy channel for a university community and its neighbors to trade information and opportunities — student jobs, local events, programs, and campus resources live in scattered slices.
        - Signal "Missing Dialogue Across Difference": People who hold differing views about a topic rarely talk with each other; new civic-engagement software is being tried, with only some success.
        - Signal "Political Bubbles & NIMBYism": Citizens are highly polarized and isolated in social bubbles, proposing solutions or pushing back on reforms without understanding the broader impacts, trade-offs, or equity implications beyond their circles.
        - Signal "Constituent Mail Black Hole": Letters and emails to representatives feel like talking into a void — heartfelt messages come back as generic, strategist-polished boilerplate.
      • Evidence: Fear — Outside civic discourse, people are afraid of talking to each other.
        - Signal "Political Bubbles & NIMBYism": Citizens are highly polarized and isolated in social bubbles, proposing solutions or pushing back on reforms without understanding the broader impacts, trade-offs, or equity implications beyond their circles.
        - Signal "Missing Dialogue Across Difference": People who hold differing views about a topic rarely talk with each other; new civic-engagement software is being tried, with only some success.
        - Signal "Loneliness as a Civic Problem": The social scaffolding that once created accountability in how people form relationships has dissolved with nothing replacing it — an isolation epidemic treated as a private matter rather than missing civic infrastructure.
        - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
  • Theme: Reduced Civic Effectiveness — When rules change, even educated, engaged citizens are rendered ineffectual.

When citizens stop trying to participate in civics, they are rendered ineffectual.

When groups of like-minded citizens are rendered ineffectual, other groups become more effective.
    • Pattern: Disenfranchisement — Some things are designed to stop people voting.                                                  
      • Evidence: Fear — Outside civic discourse, people are afraid of talking to each other.
        - Signal "Political Bubbles & NIMBYism": Citizens are highly polarized and isolated in social bubbles, proposing solutions or pushing back on reforms without understanding the broader impacts, trade-offs, or equity implications beyond their circles.
        - Signal "Missing Dialogue Across Difference": People who hold differing views about a topic rarely talk with each other; new civic-engagement software is being tried, with only some success.
        - Signal "Loneliness as a Civic Problem": The social scaffolding that once created accountability in how people form relationships has dissolved with nothing replacing it — an isolation epidemic treated as a private matter rather than missing civic infrastructure.
        - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
      • Evidence: Barriers to Participation — There are hurdles that stop people from voting.
        - Signal "Last-Mile Resource Disconnect": Programs, grants, and services exist on paper, but communities often don't know about them or can't navigate them — the gap is grassroots outreach, trusted local partners, and hands-on navigation support, not new programs.
        - Signal "Logistical & Educational Barriers to Voting": Voting is burdened by physical hurdles (childcare, time off work) and a lack of plain-language education on how local elections directly impact citizens' daily lives.
      • Evidence: Accountability — Representatives face no consequences for lying or committing crimes, which encourages them to continue doing so.
        - Signal "Representatives Without Accountability": Representatives don't seem to answer to the people, and replacing them changes little — new reps inherit the same voting patterns, with the two-party system and polarization at the crux.
        - Signal "Accountability for Public Lies": Telling the truth — and holding liars accountable and responsible — is named as the missing piece of civic life.
        - Signal "Performative Bipartisanship": Statements, town halls, and pledges perform collaboration without doing it; missing is a structured, sprint-like way for people who are supposed to disagree to define a shared problem and build something together.
      • Evidence: Deliberate Obfuscation — It may be an advantage to confuse people.
        - Signal "Uncontested Local Candidate Transparency": It is incredibly difficult to research the records of local election candidates, especially those running uncontested or without a communications budget, leaving voters feeling uninformed.
        - Signal "Representatives Without Accountability": Representatives don't seem to answer to the people, and replacing them changes little — new reps inherit the same voting patterns, with the two-party system and polarization at the crux.
        - Signal "AI Bot Interference in Constituent Engagement": Artificial intelligence is being used to flood communication channels, rendering actual, organic constituent engagement ineffective.
        - Signal "Civic Distrust & Disinformation": A toxic combination of distrust in voting, a lack of civics literacy, and internet-era disinformation is allowing political entities to manipulate voters' worst instincts.
        - Signal "Accountability for Public Lies": Telling the truth — and holding liars accountable and responsible — is named as the missing piece of civic life.
        - Signal "False Transparency in Government": Government agencies and schools exhibit a disconnect with their constituencies, presenting a 'false flag' of transparency that leaves communities feeling ignored without understanding how aggregate sentiment is utilized.
        - Signal "Performative Bipartisanship": Statements, town halls, and pledges perform collaboration without doing it; missing is a structured, sprint-like way for people who are supposed to disagree to define a shared problem and build something together.
      • Evidence: Vote Dilution — Rules are changed to benefit political entities by stopping people voting and diluting the effectiveness of their votes.
        - Signal "Structural Election Imbalances": The current electoral system features gerrymandering, dominant two-party privileges, and districts so large that politicians effectively choose their voters.
        - Signal "Mid-Decade Redistricting Shifts": California, Missouri, North Carolina, and Texas will use different congressional maps in 2026 than in 2024 due to voluntary mid-decade redistricting — unusual, and worth watching for how it shifts competitive-district counts.
        - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.
    • Pattern: Rule Changing — The rules of the game are constantly changing.
      • Evidence: Influence — Some communities have an outsized effect on representation.                                                                                                                                                                                                          
        - Signal "Campaign Finance": Reform efforts consistently hit roadblocks like the Citizens United decision.
        - Signal "Targeting Legislative Influence": It is currently too labor-intensive and expensive to identify the most effective individuals or groups to lobby specific legislators on specific issues at the right time.
        - Signal "Campaign Finance & District Competitiveness": Observations that financial influence and gerrymandering have reduced the competitiveness of congressional districts.
      • Evidence: Vote Dilution — Rules are changed to benefit political entities by stopping people voting and diluting the effectiveness of their votes.
        - Signal "Structural Election Imbalances": The current electoral system features gerrymandering, dominant two-party privileges, and districts so large that politicians effectively choose their voters.
        - Signal "Mid-Decade Redistricting Shifts": California, Missouri, North Carolina, and Texas will use different congressional maps in 2026 than in 2024 due to voluntary mid-decade redistricting — unusual, and worth watching for how it shifts competitive-district counts.
        - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.
      • Evidence: Vote Enhancement — Rules are changed to benefit voters.
        - Signal "Ranked Choice Voting Education": The implementation of ranked choice voting lacks sufficient public education to help voters understand its systemic benefits and how it changes voting behaviors.
        - Signal "Ranked-Choice Confusion Persists": Voters remain confused about how ranked choice voting works and still lack clear, unbiased information about the candidates themselves.
        - Signal "Restructuring the Political System": A high-level desire to shift the fundamental political structure of the United States to model other international systems.

---

## Evidence landscape
### What the evidence covers
Problem: PRESENT (HEAVY). The evidence trail is overwhelmingly saturated with friction points (e.g., voter confusion, volunteer burnout, communication breakdowns, and constituent fatigue).

Flux: PARTIALLY PRESENT. Captured only in isolated technological and procedural shifts, such as AI Bot Interference in Constituent Engagement and Mid-Decade Redistricting Shifts.

### Gaps — what I think is still thin
Player: ABSENT. No player cards have been constructed. While individual signals mention voters, candidates, congressional staff, and volunteers, there is no formal mapping of institutional power, specific organizational actors, or systemic gatekeepers.

History: ABSENT. The cards treat existing disengagement and systemic friction as static, present-day failures without examining how historical policies, legal precedents (such as Citizens United), or local administrative restructurings produced current conditions.

Counterfactual: ABSENT. There is no evidence examining jurisdictions, municipalities, or civic experiments where alternative mechanisms (e.g., participatory budgeting or deliberative assemblies) were implemented and succeeded or failed.

Boundary: ABSENT. The situation lacks clear boundaries. It conflates micro-level neighborhood volunteer coordination (e.g., PTA turnover, campus-neighborhood disconnect) with macro-level state/federal electoral mechanics (e.g., redistricting shifts, federal campaign finance, party polarization).

Value: ABSENT. Underlying value conflicts—such as the trade-off between administrative speed vs. democratic deliberation, or party survival vs. public transparency—are unmapped.

---

## Research access
### Who I need to hear from
Missing perspectives:

Legislative & Congressional Staffers: The operational side of the "Constituent Mail Black Hole" is presented solely from the sender's frustration. The perspective of staffers managing high volume, automated spam, and strict party line messaging is missing.

Uncontested & Hyper-Local Candidates: The specific financial, media, and personal deterrence mechanisms faced by candidates running for low-visibility local offices (e.g., school board, county commissioner).

Local Municipal Administrators & Election Officials: The career civil servants and non-partisan staff responsible for implementing changing voting rules, managing public comment periods, and running precinct logistics.

Apathetic or Rationally Disengaged Citizens: The voice of individuals who consciously choose not to engage in civic life due to rational evaluations of time/return, rather than lack of information or fear.

### What I can't reach alone — and how I might
To complete the research agenda, access must be established across specific institutional domains:

Current or Former Legislative Constituent Services Staffers

Access Gap: Understanding the internal triage mechanics of constituent communication systems.

Path to Access: Cold outreach via LinkedIn targeting former Legislative Assistants or Constituent Services Representatives (who departed office within the last 12–24 months), or connecting through congressional staff professional associations (such as the House Staff Alliance or university public policy alumni networks).

Uncontested Local Candidates and Municipal Officials

Access Gap: Ground-truthing candidate deterrence and low-visibility election mechanics.

Path to Access: Post a targeted query on municipal administration forums (e.g., state-level City Managers Associations, the International City/County Management Association [ICMA], or regional municipal league listservs) requesting 20-minute informational interviews with local election clerks or non-party municipal candidates.

Grassroots Resource Navigators ("Last-Mile" Organizers)

Access Gap: Verifying why federal/state grants and community services fail to reach local neighborhood contexts.

Path to Access: Request warm introductions through local community foundations, United Way regional directors, or neighborhood advisory committee (ANC/NAC) chairs who manage hyper-local grant distribution and neighborhood volunteering.

---

## The paradox
Communities that are able to activate their members effectively necessarily marginalize those that are not.

_Sharpness self-check (pod-declared): 0/3._

### Who benefits from the status quo
Communities that are able to activate their members effectively (corporations, foreign nations, and wealthy individuals).

### How we know (evidence as warrant)
No client handed us this problem — the evidence did. This paradox was read off **33 source extracts** across **3 named themes** (Limited Agency, Specific Needs aren't Met, Reduced Civic Effectiveness). The full trail ships with this folder (`data/extracts.csv` + the themes narrative).

Representative extracts:
- "Volunteer Burnout & Knowledge Transfer" — Local volunteer roles, such as PTA leadership, fall on a few individuals. There is a need for tools to reduce the operational burden and retain institutional knowledge as volunteer leadership turns over.
- "Misunderstood Pace of Government" — Constituents misjudge who holds which powers and how fast government was designed to move, so legitimate slowness reads as failure — and stretched congressional staff can't give every issue the weight visitors expect.

### What we're still testing
- What could break this framing: I assume that if communities are given tools needed to activate their people that they will pick up those tools and use them to help their communities.
- Sharpness still unclaimed: it names a contradiction where the fix undoes itself — x requires not-x
- Sharpness still unclaimed: it names who is invested in it persisting
- Sharpness still unclaimed: both legs of the contradiction are evidenced (linked cards / extracts)

### Pressure-testing the framing
I assume that if communities are given tools needed to activate their people that they will pick up those tools and use them to help their communities.

---

## The field — candidate problem owners
(field not yet mapped — start with the inner circle, then widen, and mark who could own this)

---

## What comes next
This situation is mapped but not solved — and solving it is not the next step. The next steps in Frame Creation are:

1. **Map the field** — identify every player connected to this situation or a future resolution. Define each by their practices and currency, not their title. Look especially for players who share the values your themes surfaced — even in distant, unexpected domains.
2. **Identify a client** — from the potential problem owners, who could own this situation or adopt a resolution? What would they need to see?
3. **Choose a delivery context** — through what kind of vehicle does a resolution reach the field? (An internal team, a government program, an open-source project, a startup, a nonprofit, a civic institution, a co-op — there is no right answer, only trade-offs.)
4. **Deepen the archaeology** — the gaps above name what's still thin. Go find it: interview people, run deep-research sweeps, pull secondary sources.
5. **Create frames** — only after the field is mapped and the archaeology is deep. "If this situation is approached as if it is ___, then ___."
